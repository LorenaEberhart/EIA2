 /*
Aufgabe: Abschlussaufgabe
Name: Lorena Eberhart
Matrikel: 256328
Datum: 23.02.18
    
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. 
Er wurde nicht kopiert und auch nicht diktiert.

*/

namespace Abschluss {
    
    export class FlagsArray {
        
        x: number;
        y: number;
        
        constructor(_x: number, _y: number) {
            this.x = _x;
            this.y = _y;
            }
        
        update(): void {
            
            }
        
        draw(): void {
            
            }
    }   
}